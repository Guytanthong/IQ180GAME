function selectAvatar(avatarSrc) {
    // Change the source of the selectedAvatar image
    document.getElementById('selectedAvatar').src = avatarSrc;
}
